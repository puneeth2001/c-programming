public class Solution {
    boolean balanced(Character a, Character b){
        if(a == null){
            return false;
        } 
        return (a == '[' && b == ']') || (a == '(' && b == ')') || (a == '{' && b == '}');
    }
    public boolean isValid(String str) {
        if(str == null) return false;
        char[] chars = str.toCharArray();
        if(chars.length == 0 || chars.length % 2 == 1){
            return false;
        }
        LinkedList<Character> stack = new LinkedList<Character>();
        for(char c: chars){
            Character peek = stack.peek();
            if(balanced(peek, c)){

                stack.pop();

            }else{

                stack.push(c);
            }
        }
        return stack.size() == 0;
    }

}
