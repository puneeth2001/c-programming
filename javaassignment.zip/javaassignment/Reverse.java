public class Solution {

    public ListNode reverseList(ListNode head) {
        if (head == null){
           return null; 
        } 
        if (head.next == null){
          return head;  
        } 
        ListNode rear = head.next;
        ListNode reversed = reverseList(head.next);
        rear.next = head;
        head.next = null;
        return reversed;
    }
}
